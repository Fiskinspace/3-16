# Carnage Amongst the Stars — Standalone VTT

A lightweight, client‑only virtual tabletop tailored to **3:16 Carnage Amongst the Stars**.  
No server, no database — **everything runs in your browser** and is saved to `localStorage`.

## Features
- Character sheet (FA, NFA, weapon, kills, strengths/weaknesses)
- Dice roller (d10 vs FA/NFA, d100 kill)
- Map canvas (upload background, add draggable colored tokens, zone label)
- Chat/log (local only)
- Persistent state saved in your browser
- Built with React + Vite + Tailwind + React‑Konva + Zustand

## Quick Start (Local)
```bash
npm i
npm run dev
```

## Deploy to Vercel
1. Create a **new GitHub repo** and upload these files (or push via CLI).
2. In Vercel: **Add New → Import Project**, pick the repo.
3. Framework preset: **Vite**  
   Build command: `npm run build`  
   Output directory: `dist`
4. Click **Deploy** → your site will be live at `https://<project>.vercel.app`

## Notes
- This is **standalone**. Multiplayer sync, accounts, and GM/Player roles require a Firebase‑enabled build (can be added later).
- Tokens: **double‑click to remove**. Use the color picker to differentiate marines/aliens.
