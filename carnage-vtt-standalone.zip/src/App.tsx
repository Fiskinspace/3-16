import React from 'react'
import Navbar from './components/Navbar'
import CharacterSheet from './components/CharacterSheet'
import DiceRoller from './components/DiceRoller'
import VTTCanvas from './components/VTTCanvas'
import ChatLog from './components/ChatLog'
import { useStore } from './store'

export default function App(){
  const reset = useStore(s=>s.reset)
  return (
    <div className='min-h-screen'>
      <Navbar/>
      <main className='max-w-7xl mx-auto p-4 space-y-4'>
        <div className='grid grid-cols-1 lg:grid-cols-3 gap-4'>
          <div className='lg:col-span-2 space-y-4'>
            <VTTCanvas/>
            <DiceRoller/>
          </div>
          <div className='space-y-4'>
            <CharacterSheet/>
            <ChatLog/>
            <button className='w-full underline text-sm' onClick={reset}>Reset All (local only)</button>
          </div>
        </div>
        <footer className='text-center text-slate-400 text-sm py-6'>
          Standalone client — no accounts, no servers. Your data stays in your browser.
        </footer>
      </main>
    </div>
  )
}
