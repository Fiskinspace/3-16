import React, { useState } from 'react'
import { useStore } from '../store'

export default function CharacterSheet(){
  const c = useStore(s=>s.character)
  const setCharacter = useStore(s=>s.setCharacter)
  const addChat = useStore(s=>s.addChat)
  const [strength, setStrength] = useState('')
  const [weakness, setWeakness] = useState('')

  return (
    <div className='card p-4 space-y-3'>
      <div className='font-semibold'>Character Sheet</div>
      <div className='grid grid-cols-2 md:grid-cols-4 gap-3'>
        <div>
          <label className='label'>Name</label>
          <input className='input' value={c.name} onChange={e=>setCharacter({name:e.target.value})}/>
        </div>
        <div>
          <label className='label'>FA</label>
          <input type='number' className='input' value={c.fa} min={1} max={10} onChange={e=>setCharacter({fa: Number(e.target.value)})}/>
        </div>
        <div>
          <label className='label'>NFA</label>
          <input type='number' className='input' value={c.nfa} min={1} max={10} onChange={e=>setCharacter({nfa: Number(e.target.value)})}/>
        </div>
        <div>
          <label className='label'>Weapon</label>
          <input className='input' value={c.weapon} onChange={e=>setCharacter({weapon:e.target.value})}/>
        </div>
      </div>
      <div className='grid grid-cols-1 md:grid-cols-3 gap-3'>
        <div className='card p-3'>
          <div className='font-medium mb-2'>Strengths</div>
          <div className='flex gap-2'>
            <input className='input' placeholder='Add strength' value={strength} onChange={e=>setStrength(e.target.value)}/>
            <button className='btn' onClick={()=>{ if(strength.trim()){ useStore.getState().setCharacter({ strengths: [...c.strengths, strength.trim()]}); setStrength('') }}}>Add</button>
          </div>
          <ul className='mt-2 list-disc pl-5 space-y-1'>
            {c.strengths.map((s,i)=>(<li key={i} className='flex justify-between items-center'><span>{s}</span><button className='text-xs underline' onClick={()=>useStore.getState().setCharacter({ strengths: c.strengths.filter((_,j)=>j!==i) })}>remove</button></li>))}
          </ul>
        </div>
        <div className='card p-3'>
          <div className='font-medium mb-2'>Weaknesses</div>
          <div className='flex gap-2'>
            <input className='input' placeholder='Add weakness' value={weakness} onChange={e=>setWeakness(e.target.value)}/>
            <button className='btn' onClick={()=>{ if(weakness.trim()){ useStore.getState().setCharacter({ weaknesses: [...c.weaknesses, weakness.trim()]}); setWeakness('') }}}>Add</button>
          </div>
          <ul className='mt-2 list-disc pl-5 space-y-1'>
            {c.weaknesses.map((s,i)=>(<li key={i} className='flex justify-between items-center'><span>{s}</span><button className='text-xs underline' onClick={()=>useStore.getState().setCharacter({ weaknesses: c.weaknesses.filter((_,j)=>j!==i) })}>remove</button></li>))}
          </ul>
        </div>
        <div className='card p-3'>
          <div className='font-medium mb-2'>Kills</div>
          <div className='flex gap-2 items-center'>
            <button className='btn' onClick={()=>useStore.getState().setCharacter({ kills: Math.max(0, c.kills-1) })}>-</button>
            <div className='text-2xl font-bold tabular-nums'>{c.kills}</div>
            <button className='btn' onClick={()=>useStore.getState().setCharacter({ kills: c.kills+1 })}>+</button>
          </div>
          <button className='mt-2 underline text-sm' onClick={()=>addChat(`☠️ ${c.name} total kills: ${c.kills}`)}>Announce to chat</button>
        </div>
      </div>
    </div>
  )
}
