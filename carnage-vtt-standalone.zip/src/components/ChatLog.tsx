import React, { useRef, useEffect, useState } from 'react'
import { useStore } from '../store'

export default function ChatLog(){
  const chat = useStore(s=>s.chat)
  const addChat = useStore(s=>s.addChat)
  const [msg, setMsg] = useState('')
  const ref = useRef<HTMLDivElement>(null)

  useEffect(()=>{
    ref.current?.scrollTo({ top: ref.current.scrollHeight, behavior: 'smooth' })
  }, [chat.length])

  const send = ()=>{
    const text = msg.trim()
    if(!text) return
    addChat(text)
    setMsg('')
  }

  return (
    <div className='card p-4 flex flex-col h-[360px]'>
      <div className='font-semibold mb-2'>Chat & Log</div>
      <div ref={ref} className='flex-1 overflow-y-auto space-y-2 pr-2'>
        {chat.map(c=>(<div key={c.id} className='text-sm'>
          <span className='text-slate-400'>{new Date(c.ts).toLocaleTimeString()} — </span>
          {c.text}
        </div>))}
      </div>
      <div className='mt-2 flex gap-2'>
        <input className='input flex-1' placeholder='Say something…' value={msg} onChange={e=>setMsg(e.target.value)} onKeyDown={e=> e.key==='Enter' && send() }/>
        <button className='btn' onClick={send}>Send</button>
      </div>
    </div>
  )
}
