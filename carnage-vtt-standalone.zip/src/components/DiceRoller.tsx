import React from 'react'
import { useStore } from '../store'

function roll(n:number, sides:number){
  return Array.from({length:n}, ()=> 1+Math.floor(Math.random()*sides))
}

export default function DiceRoller(){
  const addChat = useStore(s=>s.addChat)
  const character = useStore(s=>s.character)

  const doFA = ()=>{
    const r = roll(1,10)[0]
    const success = r <= character.fa
    addChat(`🎲 FA roll ${r} vs ${character.fa} → ${success ? 'SUCCESS' : 'FAIL'}`)
  }
  const doNFA = ()=>{
    const r = roll(1,10)[0]
    const success = r <= character.nfa
    addChat(`🎲 NFA roll ${r} vs ${character.nfa} → ${success ? 'SUCCESS' : 'FAIL'}`)
  }
  const doKill = ()=>{
    const r = roll(1,100)[0]
    addChat(`💥 Kill roll d100 → ${r}`)
  }

  return (
    <div className='card p-4 space-y-2'>
      <div className='font-semibold'>Dice Roller</div>
      <div className='flex gap-2 flex-wrap'>
        <button className='btn' onClick={doFA}>Roll FA (d10 ≤ {character.fa})</button>
        <button className='btn' onClick={doNFA}>Roll NFA (d10 ≤ {character.nfa})</button>
        <button className='btn' onClick={doKill}>Kill Roll (d100)</button>
      </div>
    </div>
  )
}
