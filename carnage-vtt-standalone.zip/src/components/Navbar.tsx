import React from 'react'

export default function Navbar(){
  return (
    <div className='w-full sticky top-0 z-40 card p-3 flex items-center justify-between'>
      <div className='font-bold text-lg'>🛰️ Carnage Amongst the Stars — VTT (Standalone)</div>
      <a className='btn' href='https://gregorhutton.com/boxninja/threesixteen/' target='_blank'>Game SRD</a>
    </div>
  )
}
