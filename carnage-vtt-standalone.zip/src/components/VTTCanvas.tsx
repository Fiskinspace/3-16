import React, { useRef, useState } from 'react'
import { Stage, Layer, Rect, Text as KText, Circle, Image as KImage } from 'react-konva'
import { useStore } from '../store'

function useImageFromDataUrl(dataUrl?: string){
  const [img, setImg] = useState<HTMLImageElement | null>(null)
  React.useEffect(()=>{
    if(!dataUrl){ setImg(null); return }
    const i = new Image()
    i.onload = ()=> setImg(i)
    i.src = dataUrl
  }, [dataUrl])
  return img
}

export default function VTTCanvas(){
  const { tokens, addToken, updateToken, removeToken, zone, setZone, backgroundDataUrl, setBackground } = useStore()
  const stageRef = useRef<any>(null)
  const img = useImageFromDataUrl(backgroundDataUrl)
  const [adding, setAdding] = useState(false)
  const [label, setLabel] = useState('Trooper')
  const [color, setColor] = useState('#60a5fa')

  const handleAddClick = () => setAdding(true)

  const handleStageClick = (e:any)=>{
    if(!adding) return
    const pos = e.target.getStage().getPointerPosition()
    addToken({ id: crypto.randomUUID(), x: pos.x, y: pos.y, label, color, visible: true })
    setAdding(false)
  }

  const uploadBg = (file: File)=>{
    const reader = new FileReader()
    reader.onload = ()=> setBackground(reader.result as string)
    reader.readAsDataURL(file)
  }

  const clearBg = ()=> setBackground(undefined)

  return (
    <div className='card p-4 space-y-3'>
      <div className='flex items-center justify-between flex-wrap gap-2'>
        <div className='font-semibold'>VTT Map</div>
        <div className='flex gap-2 items-center'>
          <select value={zone} onChange={e=>setZone(e.target.value as any)} className='input w-32'>
            <option>Close</option>
            <option>Near</option>
            <option>Far</option>
          </select>
          <input className='input w-40' value={label} onChange={e=>setLabel(e.target.value)} placeholder='Token label'/>
          <input type='color' className='w-10 h-10 rounded' value={color} onChange={e=>setColor(e.target.value)}/>
          <button className='btn' onClick={handleAddClick}>Add Token</button>
          <label className='btn cursor-pointer'>
            Upload Background
            <input type='file' className='hidden' accept='image/*' onChange={e=>{const f=e.target.files?.[0]; if(f) uploadBg(f)}}/>
          </label>
          <button className='btn' onClick={clearBg}>Clear BG</button>
        </div>
      </div>
      <Stage width={1024} height={576} ref={stageRef} onMouseDown={handleStageClick} className='rounded-2xl overflow-hidden border border-slate-700 bg-slate-900'>
        <Layer>
          {img && <KImage image={img} width={1024} height={576} />}
          {/* zone banner */}
          <Rect x={0} y={0} width={1024} height={28} fill='rgba(2,6,23,0.6)' />
          <KText x={10} y={6} text={`Zone: ${zone}`} fontSize={16} fill='#fff' />
        </Layer>
        <Layer>
          {tokens.map(t=>(
            <React.Fragment key={t.id}>
              <Circle
                x={t.x} y={t.y} radius={18} fill={t.color} draggable
                onDragEnd={(e)=> updateToken(t.id, { x: e.target.x(), y: e.target.y() })}
                onDblClick={()=> removeToken(t.id)}
              />
              <KText x={t.x-30} y={t.y+22} text={t.label} fontSize={14} fill='#fff' />
            </React.Fragment>
          ))}
        </Layer>
      </Stage>
      <div className='text-sm text-slate-400'>Tip: Double‑click a token to remove it.</div>
    </div>
  )
}
