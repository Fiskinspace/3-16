import { create } from 'zustand'

export type Character = {
  name: string
  fa: number
  nfa: number
  weapon: string
  kills: number
  strengths: string[]
  weaknesses: string[]
}

export type Token = { id: string; x: number; y: number; label: string; color: string; visible: boolean }

export type ChatEntry = { id: string; text: string; ts: number }

type State = {
  character: Character
  tokens: Token[]
  chat: ChatEntry[]
  zone: 'Close'|'Near'|'Far'
  backgroundDataUrl?: string
  addChat: (text: string) => void
  addToken: (t: Token) => void
  updateToken: (id: string, p: Partial<Token>) => void
  removeToken: (id: string) => void
  setBackground: (dataUrl?: string) => void
  setZone: (z: State['zone']) => void
  setCharacter: (p: Partial<Character>) => void
  reset: () => void
}

const defaultChar: Character = {
  name: 'Trooper',
  fa: 5,
  nfa: 5,
  weapon: 'Rifle',
  kills: 0,
  strengths: [],
  weaknesses: []
}

const persisted = localStorage.getItem('carnage-vtt-state')

const initial: Omit<State,'addChat'|'addToken'|'updateToken'|'removeToken'|'setBackground'|'setZone'|'setCharacter'|'reset'> = persisted ? JSON.parse(persisted) : {
  character: defaultChar,
  tokens: [],
  chat: [],
  zone: 'Near',
  backgroundDataUrl: undefined,
}

export const useStore = create<State>((set, get) => ({
  ...initial,
  addChat: (text) => set(s => ({ chat: [...s.chat, { id: crypto.randomUUID(), text, ts: Date.now() }] })),
  addToken: (t) => set(s => ({ tokens: [...s.tokens, t] })),
  updateToken: (id, p) => set(s => ({ tokens: s.tokens.map(t => t.id===id ? { ...t, ...p } : t) })),
  removeToken: (id) => set(s => ({ tokens: s.tokens.filter(t => t.id!==id) })),
  setBackground: (u) => set({ backgroundDataUrl: u }),
  setZone: (z) => set({ zone: z }),
  setCharacter: (p) => set(s => ({ character: { ...s.character, ...p } })),
  reset: () => set({ character: defaultChar, tokens: [], chat: [], zone: 'Near', backgroundDataUrl: undefined })
}))

// persist to localStorage
useStore.subscribe((state) => {
  const { addChat, addToken, updateToken, removeToken, setBackground, setZone, setCharacter, reset, ...persistable } = state as any
  localStorage.setItem('carnage-vtt-state', JSON.stringify(persistable))
})
